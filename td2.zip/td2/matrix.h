#ifndef MATRIX_H
#define MATRIX_H

#include <vector>
#include <iostream>
#include <stdexcept>
#include <cmath>

template<typename T>
class MatrixBase {
protected:
    std::vector<std::vector<T>> data;
    size_t rows;
    size_t cols;

public:
    MatrixBase();
    MatrixBase(size_t r, size_t c);

    void addElement(size_t r, size_t c, T value);
    T getElement(size_t r, size_t c) const;

    size_t getRows() const { return rows; }
    size_t getCols() const { return cols; }

    void Display() const;
};

template<typename T>
class MatrixNumerical : public MatrixBase<T> {
public:
    MatrixNumerical();
    MatrixNumerical(size_t r, size_t c);

    T getDeterminant() const;

    MatrixNumerical operator+(const MatrixNumerical& other) const;
    MatrixNumerical operator-(const MatrixNumerical& other) const;
    MatrixNumerical operator*(const MatrixNumerical& other) const;
    MatrixNumerical operator/(const MatrixNumerical& other) const;

    MatrixNumerical getInverse() const;

    static MatrixNumerical getIdentity(int size);
    

private:
    static T determinant(const MatrixNumerical& matrix);
    static T getCoFactor(const MatrixNumerical& matrix, size_t row, size_t col);
    MatrixNumerical transpose() const;
};

// Implémentations des méthodes template
// Note: Normalement, ces implémentations seraient dans un fichier .tpp séparé,
// mais pour simplifier, nous les incluons ici.

// Implémentations pour MatrixBase
template<typename T>
MatrixBase<T>::MatrixBase() : rows(0), cols(0) {}

template<typename T>
MatrixBase<T>::MatrixBase(size_t r, size_t c) : rows(r), cols(c), data(r, std::vector<T>(c)) {}

template<typename T>
void MatrixBase<T>::addElement(size_t r, size_t c, T value) {
    if (r >= rows || c >= cols) {
        throw std::out_of_range("Index out of range");
    }
    data[r][c] = value;
}

template<typename T>
T MatrixBase<T>::getElement(size_t r, size_t c) const {
    if (r >= rows || c >= cols) {
        throw std::out_of_range("Index out of range");
    }
    return data[r][c];
}

template<typename T>
void MatrixBase<T>::Display() const {
    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            std::cout << data[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

// Implémentations pour MatrixNumerical
template<typename T>
MatrixNumerical<T>::MatrixNumerical() : MatrixBase<T>() {}

template<typename T>
MatrixNumerical<T>::MatrixNumerical(size_t r, size_t c) : MatrixBase<T>(r, c) {}

// Note: Les implémentations détaillées des autres méthodes de MatrixNumerical
// (comme getDeterminant, getInverse, les opérateurs, etc.) seraient normalement
// dans un fichier .cpp séparé. Ici, nous les déclarons seulement.

#endif // MATRIX_H