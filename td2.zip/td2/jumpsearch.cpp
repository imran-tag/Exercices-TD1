#include "jumpsearch.h"

int JumpSearch::search(const std::vector<int>& vec, int element) {
    reset();  // Reset the comparison counter
    int n = vec.size();
    int step = std::sqrt(n);
    int prev = 0;

    while (vec[std::min(step, n) - 1] < element) {
        incrementComparisons();
        prev = step;
        step += std::sqrt(n);
        if (prev >= n) {
            return -1;
        }
    }

    while (vec[prev] < element) {
        incrementComparisons();
        prev++;
        if (prev == std::min(step, n)) {
            return -1;
        }
    }

    incrementComparisons();
    if (vec[prev] == element) {
        return prev;
    }

    return -1;
}