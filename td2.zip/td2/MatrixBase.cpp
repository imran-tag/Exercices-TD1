#include "matrix.h"

// Implémentation des méthodes de MatrixNumerical

template<typename T>
T MatrixNumerical<T>::getDeterminant() const {
    if (this->rows != this->cols) {
        throw std::runtime_error("Matrix is not square");
    }
    return determinant(*this);
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::operator+(const MatrixNumerical<T>& other) const {
    if (this->rows != other.rows || this->cols != other.cols) {
        throw std::runtime_error("Matrix dimensions do not match");
    }
    MatrixNumerical<T> result(this->rows, this->cols);
    for (size_t i = 0; i < this->rows; ++i) {
        for (size_t j = 0; j < this->cols; ++j) {
            result.data[i][j] = this->data[i][j] + other.data[i][j];
        }
    }
    return result;
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::operator-(const MatrixNumerical<T>& other) const {
    if (this->rows != other.rows || this->cols != other.cols) {
        throw std::runtime_error("Matrix dimensions do not match");
    }
    MatrixNumerical<T> result(this->rows, this->cols);
    for (size_t i = 0; i < this->rows; ++i) {
        for (size_t j = 0; j < this->cols; ++j) {
            result.data[i][j] = this->data[i][j] - other.data[i][j];
        }
    }
    return result;
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::operator*(const MatrixNumerical<T>& other) const {
    if (this->cols != other.rows) {
        throw std::runtime_error("Matrix dimensions are not compatible for multiplication");
    }
    MatrixNumerical<T> result(this->rows, other.cols);
    for (size_t i = 0; i < this->rows; ++i) {
        for (size_t j = 0; j < other.cols; ++j) {
            T sum = 0;
            for (size_t k = 0; k < this->cols; ++k) {
                sum += this->data[i][k] * other.data[k][j];
            }
            result.data[i][j] = sum;
        }
    }
    return result;
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::getInverse() const {
    T det = getDeterminant();
    if (std::abs(det) < 1e-9) {
        throw std::runtime_error("Matrix is not invertible");
    }

    MatrixNumerical<T> cofactor(this->rows, this->cols);
    for (size_t i = 0; i < this->rows; ++i) {
        for (size_t j = 0; j < this->cols; ++j) {
            cofactor.data[i][j] = getCoFactor(*this, i, j) * ((i + j) % 2 == 0 ? 1 : -1);
        }
    }

    MatrixNumerical<T> adjoint = cofactor.transpose();
    MatrixNumerical<T> inverse = adjoint * (1 / det);
    return inverse;
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::operator/(const MatrixNumerical<T>& other) const {
    return (*this) * other.getInverse();
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::getIdentity(int size) {
    MatrixNumerical<T> identity(size, size);
    for (int i = 0; i < size; ++i) {
        identity.data[i][i] = 1;
    }
    return identity;
}

// Méthodes privées

template<typename T>
T MatrixNumerical<T>::determinant(const MatrixNumerical<T>& matrix) {
    if (matrix.rows == 1) {
        return matrix.data[0][0];
    }
    if (matrix.rows == 2) {
        return matrix.data[0][0] * matrix.data[1][1] - matrix.data[0][1] * matrix.data[1][0];
    }
    T det = 0;
    for (size_t j = 0; j < matrix.cols; ++j) {
        det += matrix.data[0][j] * getCoFactor(matrix, 0, j) * (j % 2 == 0 ? 1 : -1);
    }
    return det;
}

template<typename T>
T MatrixNumerical<T>::getCoFactor(const MatrixNumerical<T>& matrix, size_t row, size_t col) {
    MatrixNumerical<T> submatrix(matrix.rows - 1, matrix.cols - 1);
    for (size_t i = 0, si = 0; i < matrix.rows; ++i) {
        if (i == row) continue;
        for (size_t j = 0, sj = 0; j < matrix.cols; ++j) {
            if (j == col) continue;
            submatrix.data[si][sj] = matrix.data[i][j];
            ++sj;
        }
        ++si;
    }
    return determinant(submatrix);
}

template<typename T>
MatrixNumerical<T> MatrixNumerical<T>::transpose() const {
    MatrixNumerical<T> result(this->cols, this->rows);
    for (size_t i = 0; i < this->rows; ++i) {
        for (size_t j = 0; j < this->cols; ++j) {
            result.data[j][i] = this->data[i][j];
        }
    }
    return result;
}

// Instanciations explicites pour les types courants
template class MatrixNumerical<int>;
template class MatrixNumerical<float>;
template class MatrixNumerical<double>;