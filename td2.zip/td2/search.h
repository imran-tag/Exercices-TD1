#ifndef SEARCHING_ALGORITHM_H
#define SEARCHING_ALGORITHM_H

#include <vector>
#include <ostream>

class SearchingAlgorithm {
private:
    int numberComparisons;
    static int totalComparisons;
    static int totalSearch;
    static double averageComparisons;

public:
    SearchingAlgorithm();
    virtual ~SearchingAlgorithm() = default;

    virtual int search(const std::vector<int>& vec, int element) = 0;

    void incrementComparisons();
    static void updateStats();
    void reset();
    static void resetAll();

    int getNumberComparisons() const;
    static int getTotalComparisons();
    static int getTotalSearch();
    static double getAverageComparisons();

    void displaySearchResults(std::ostream& os, int result, int target);
};

#endif // SEARCHING_ALGORITHM_H