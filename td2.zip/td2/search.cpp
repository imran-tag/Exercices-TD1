#include "search.h"
#include <iostream>

// Initialisation des variables statiques
int SearchingAlgorithm::totalComparisons = 0;
int SearchingAlgorithm::totalSearch = 0;
double SearchingAlgorithm::averageComparisons = 0.0;

SearchingAlgorithm::SearchingAlgorithm() : numberComparisons(0) {}

void SearchingAlgorithm::incrementComparisons() {
    numberComparisons++;
    totalComparisons++;
}

void SearchingAlgorithm::updateStats() {
    totalSearch++;
    if (totalSearch > 0) {
        averageComparisons = static_cast<double>(totalComparisons) / totalSearch;
    }
}

void SearchingAlgorithm::reset() {
    numberComparisons = 0;
}

void SearchingAlgorithm::resetAll() {
    totalComparisons = 0;
    totalSearch = 0;
    averageComparisons = 0.0;
}

int SearchingAlgorithm::getNumberComparisons() const {
    return numberComparisons;
}

int SearchingAlgorithm::getTotalComparisons() {
    return totalComparisons;
}

int SearchingAlgorithm::getTotalSearch() {
    return totalSearch;
}

double SearchingAlgorithm::getAverageComparisons() {
    return averageComparisons;
}

void SearchingAlgorithm::displaySearchResults(std::ostream& os, int result, int target) {
    updateStats();  // Met à jour totalSearch et averageComparisons

    os << "Searching for " << target << ":\n";
    if (result != -1) {
        os << "Element found at index " << result << "\n";
    } else {
        os << "Element not found\n";
    }
    os << "Number of comparisons: " << numberComparisons << "\n";
    os << "Total comparisons: " << totalComparisons << "\n";
    os << "Average comparisons: " << averageComparisons << "\n";
}