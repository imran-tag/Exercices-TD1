#include "linear.h"

int LinearSearch::search(const std::vector<int>& vec, int element) {
    reset();  // Reset the comparison counter
    for (int i = 0; i < vec.size(); ++i) {
        incrementComparisons();
        if (vec[i] == element) {
            return i;
        }
    }
    return -1;
}