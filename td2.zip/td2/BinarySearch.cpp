#include "BinarySearch.h"

int BinarySearch::search(const std::vector<int>& vec, int element) {
    reset();  // Reset the comparison counter
    int left = 0;
    int right = vec.size() - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        
        incrementComparisons();
        if (vec[mid] == element) {
            return mid;
        }
        
        incrementComparisons();
        if (vec[mid] < element) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    return -1;
}