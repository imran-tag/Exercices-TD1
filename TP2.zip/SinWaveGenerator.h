#pragma once
#include "TimeSeriesGenerator.h"

class SinWaveGenerator : public TimeSeriesGenerator {
public:
   SinWaveGenerator(double amplitude = 1.0, double frequency = 1.0, double phase = 0.0);
   std::vector<double> generateTimeSeries(int size) override;

private:
   double amplitude, frequency, phase;
};