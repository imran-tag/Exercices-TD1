#include "StepGenerator.h"
#include <random>

StepGenerator::StepGenerator() = default;

std::vector<double> StepGenerator::generateTimeSeries(int size) {
   static std::random_device rd;
   std::mt19937 gen(rd());
   std::uniform_int_distribution<> dist(0, 100);
   std::bernoulli_distribution flip(0.5);

   std::vector<double> series(size);
   for (int i = 1; i < size; ++i) {
       series[i] = flip(gen) ? series[i-1] : dist(gen);
   }
   return series;
}