#pragma once
#include <vector>

class TimeSeriesGenerator {
public:
   TimeSeriesGenerator();
   explicit TimeSeriesGenerator(int seed);
   virtual ~TimeSeriesGenerator() = default;
   
   virtual std::vector<double> generateTimeSeries(int size) = 0;
   static void printTimeSeries(const std::vector<double>& series);

protected:
   int seed;
};