#pragma once
#include <vector>
#include <string>
#include "TimeSeriesDataset.h"

class KNN {
private:
   int k;
   std::string distanceMetric;
   double euclideanDistance(const std::vector<double>& series1, const std::vector<double>& series2) const;
   double dtwDistance(const std::vector<double>& series1, const std::vector<double>& series2) const;

public:
   KNN(int neighbors, const std::string& metric);
   int predict(const std::vector<double>& testSeries, const TimeSeriesDataset& trainData);
   double evaluate(const TimeSeriesDataset& trainData, const TimeSeriesDataset& testData, 
                  const std::vector<int>& groundTruth);
};