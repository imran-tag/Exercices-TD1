#include "TimeSeriesDataset.h"
#include <numeric>
#include <cmath>

TimeSeriesDataset::TimeSeriesDataset(bool zNorm, bool train) 
   : znormalize(zNorm), isTrain(train) {}

void TimeSeriesDataset::addTimeSeries(const std::vector<double>& series, int label) {
   std::vector<double> normalized = series;
   if (znormalize) normalizeSeries(normalized);
   data.push_back(normalized);
   labels.push_back(label);
}

void TimeSeriesDataset::normalizeSeries(std::vector<double>& series) {
   const double mean = std::accumulate(series.begin(), series.end(), 0.0) / series.size();
   
   const double variance = std::transform_reduce(series.begin(), series.end(), 0.0, std::plus<>(),
       [mean](double x) { return std::pow(x - mean, 2); }) / series.size();
   
   const double stddev = std::sqrt(variance);
   for (double& val : series) {
       val = (val - mean) / stddev;
   }
}

const std::vector<std::vector<double>>& TimeSeriesDataset::getData() const { return data; }
const std::vector<int>& TimeSeriesDataset::getLabels() const { return labels; }