#pragma once
#include <vector>

class TimeSeriesDataset {
public:
   TimeSeriesDataset(bool znormalize, bool isTrain);
   void addTimeSeries(const std::vector<double>& series, int label);
   void normalizeSeries(std::vector<double>& series);
   const std::vector<std::vector<double>>& getData() const;
   const std::vector<int>& getLabels() const;

private:
   std::vector<std::vector<double>> data;
   std::vector<int> labels;
   bool znormalize, isTrain;
   int maxLength;
};