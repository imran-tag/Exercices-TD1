#pragma once  

#include "TimeSeriesGenerator.h"

class GaussianGenerator : public TimeSeriesGenerator {
public:
    GaussianGenerator(double mean = 0.0, double stddev = 1.0);
    std::vector<double> generateTimeSeries(int size) override;

private:
    double mean, stddev;  
};