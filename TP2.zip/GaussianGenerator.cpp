#include "GaussianGenerator.h"
#include <random>

GaussianGenerator::GaussianGenerator(double m, double s) 
    : mean(m), stddev(s) {}

std::vector<double> GaussianGenerator::generateTimeSeries(int size) {
    static std::random_device rd;  
    std::mt19937 gen(rd());  
    std::normal_distribution dist(mean, stddev); 

    std::vector<double> series(size);
    for (auto& value : series) {
        value = dist(gen);
    }
    return series;
}