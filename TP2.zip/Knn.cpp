#include "KNN.h"
#include <algorithm>
#include <queue>

KNN::KNN(int neighbors, const std::string& metric) : k(neighbors), distanceMetric(metric) {}

double KNN::euclideanDistance(const std::vector<double>& series1, const std::vector<double>& series2) const {
   double distance = 0.0;
   for (size_t i = 0; i < series1.size(); ++i) {
       distance += std::pow(series1[i] - series2[i], 2);
   }
   return std::sqrt(distance);
}

double KNN::dtwDistance(const std::vector<double>& series1, const std::vector<double>& series2) const {
   const size_t n = series1.size(), m = series2.size();
   std::vector<std::vector<double>> dtw(n + 1, std::vector<double>(m + 1, std::numeric_limits<double>::infinity()));
   dtw[0][0] = 0.0;

   for (size_t i = 1; i <= n; ++i) {
       for (size_t j = 1; j <= m; ++j) {
           double cost = std::pow(series1[i - 1] - series2[j - 1], 2);
           dtw[i][j] = cost + std::min({dtw[i-1][j], dtw[i][j-1], dtw[i-1][j-1]});
       }
   }
   return std::sqrt(dtw[n][m]);
}

int KNN::predict(const std::vector<double>& testSeries, const TimeSeriesDataset& trainData) {
   const auto& trainDataSeries = trainData.getData();
   const auto& trainLabels = trainData.getLabels();
   std::vector<std::pair<double, int>> distances;
   
   for (size_t i = 0; i < trainDataSeries.size(); ++i) {
       double distance = (distanceMetric == "euclidean_distance") ? 
           euclideanDistance(testSeries, trainDataSeries[i]) : 
           dtwDistance(testSeries, trainDataSeries[i]);
       distances.emplace_back(distance, trainLabels[i]);
   }
   
   std::partial_sort(distances.begin(), distances.begin() + k, distances.end());
   
   std::vector<int> labelCount(3);
   for (int i = 0; i < k; ++i) {
       labelCount[distances[i].second]++;
   }
   
   return std::max_element(labelCount.begin(), labelCount.end()) - labelCount.begin();
}

double KNN::evaluate(const TimeSeriesDataset& trainData, const TimeSeriesDataset& testData, 
                   const std::vector<int>& groundTruth) {
   int correct = 0;
   const auto& testDataSeries = testData.getData();
   
   for (size_t i = 0; i < testDataSeries.size(); ++i) {
       if (predict(testDataSeries[i], trainData) == groundTruth[i]) {
           correct++;
       }
   }
   
   return static_cast<double>(correct) / groundTruth.size();
}