#pragma once
#include "TimeSeriesGenerator.h"

class StepGenerator : public TimeSeriesGenerator {
public:
   StepGenerator();
   std::vector<double> generateTimeSeries(int size) override;
};