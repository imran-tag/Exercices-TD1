#include "GaussianGenerator.h"
#include "SinWaveGenerator.h"
#include "StepGenerator.h"
#include "TimeSeriesDataset.h"
#include "KNN.h"
#include <iostream>

int main() {
   TimeSeriesDataset trainData(false, true), testData(false, false);
   GaussianGenerator gauss;
   SinWaveGenerator sin;
   StepGenerator step;

   for (int i = 0; i < 2; i++) {
       trainData.addTimeSeries(gauss.generateTimeSeries(11), 0);
       trainData.addTimeSeries(sin.generateTimeSeries(11), 1);
       trainData.addTimeSeries(step.generateTimeSeries(11), 2);
   }

   std::vector<int> groundTruth = {0, 1, 2};
   testData.addTimeSeries(gauss.generateTimeSeries(11), -1);
   testData.addTimeSeries(sin.generateTimeSeries(11), -1);
   testData.addTimeSeries(step.generateTimeSeries(11), -1);

   std::cout << KNN(1, "dtw").evaluate(trainData, testData, groundTruth) << '\n'
             << KNN(2, "euclidean_distance").evaluate(trainData, testData, groundTruth) << '\n'
             << KNN(3, "euclidean_distance").evaluate(trainData, testData, groundTruth) << '\n';

   return 0;
}