#ifndef COMPLEX2D_H
#define COMPLEX2D_H

class Complex2D {
private:
    double re;
    double im;

public:
    // Constructeurs
    Complex2D();
    Complex2D(double r, double i);
    Complex2D(double value);
    Complex2D(const Complex2D& other);

    // Set and get
    double getReal() const { return re; }
    double getImag() const { return im; }
    void setReal(double r) { re = r; }
    void setImag(double i) { im = i; }

    // Opérations de base
    Complex2D operator+(const Complex2D& other) const;
    Complex2D operator*(const Complex2D& other) const;
    Complex2D symetrie() const;  // Symétrie (négation)
    Complex2D inverse() const;   

    // Opérations dérivées
    Complex2D operator-(const Complex2D& other) const;
    Complex2D operator/(const Complex2D& other) const;

    
};

#endif 