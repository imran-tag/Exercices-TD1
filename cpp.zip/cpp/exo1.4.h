#ifndef MYCLASS_H
#define MYCLASS_H

#include <string>

class MyClass {
private:
    std::string myElement;

public:
    MyClass(); 
    MyClass(const std::string& element); 
    void printMyElement() const;
};

#endif