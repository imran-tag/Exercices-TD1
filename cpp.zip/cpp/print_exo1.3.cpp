#include "exo1.3.h"
#include <iostream>

void print(const char* message) {
    std::cout << message << std::endl;
}