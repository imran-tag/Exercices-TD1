#include "Complex2D.h"
#include <stdexcept>
#include <cmath>

// Implémentation des constructeurs
Complex2D::Complex2D() : re(0), im(0) {}
Complex2D::Complex2D(double r, double i) : re(r), im(i) {}
Complex2D::Complex2D(double value) : re(value), im(value) {}
Complex2D::Complex2D(const Complex2D& other) : re(other.re), im(other.im) {}

// Opérations de base
Complex2D Complex2D::operator+(const Complex2D& other) const {
    return Complex2D(re + other.re, im + other.im);
}

Complex2D Complex2D::operator*(const Complex2D& other) const {
    return Complex2D(
        re * other.re - im * other.im,
        re * other.im + im * other.re
    );
}

Complex2D Complex2D::symetrie() const {  // Renommé de operator-() à symetrie()
    return Complex2D(-re, -im);
}

Complex2D Complex2D::inverse() const {
    double n = norm();
    if (n == 0) {
        throw std::runtime_error("Division by zero in complex inverse");
    }
    return Complex2D(real / n, -imag / n);
}

// Opérations dérivées
Complex2D Complex2D::operator-(const Complex2D& other) const {
    return *this + other.symetrie();  // Utilisation de symetrie() au lieu de -other
}

Complex2D Complex2D::operator/(const Complex2D& other) const {
    return *this * other.inverse();
}

// Fonction utilitaire
double Complex2D::norm() const {
    return real * real + imag * imag;
}