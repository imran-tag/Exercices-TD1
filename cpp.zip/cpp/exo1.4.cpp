#include "exo1.4.h"
#include <iostream>

int main() {
    MyClass obj1; 
    MyClass obj2("Hello, World!"); 

    std::cout << "Object 1: ";
    obj1.printMyElement();

    std::cout << "Object 2: ";
    obj2.printMyElement();

    return 0;
}