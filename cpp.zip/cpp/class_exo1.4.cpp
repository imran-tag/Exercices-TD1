#include "exo1.4.h"
#include <iostream>

MyClass::MyClass() : myElement("Valeur par défaut") {}

MyClass::MyClass(const std::string& element) : myElement(element) {}

void MyClass::printMyElement() const {
    std::cout << myElement << std::endl;
}
