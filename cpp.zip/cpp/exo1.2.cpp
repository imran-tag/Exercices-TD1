#include <iostream>

void print(const char* message) {
    std::cout << message << std::endl;
}

int main() {
    print("Hello World !");
    return 0;
}