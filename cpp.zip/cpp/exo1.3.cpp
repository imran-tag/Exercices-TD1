#include "exo1.3.h"

int main() {
    print("Hello World !");
    return 0;
}