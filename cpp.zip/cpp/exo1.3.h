#ifndef PRINT_H
#define PRINT_H

void print(const char* message);

#endif